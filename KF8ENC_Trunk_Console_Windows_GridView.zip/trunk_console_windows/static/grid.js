const $ = id => document.getElementById(id);
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const ageText = seconds => seconds == null ? "—" : seconds < 2 ? "just now" : seconds < 60 ? `${Math.floor(seconds)}s ago` : `${Math.floor(seconds / 60)}m ago`;
let data = null;

function render() {
  if (!data) return;
  const query = $("search").value.trim().toLowerCase();
  const recentOnly = $("recent-only").checked;
  const rows = data.grid_talkgroups.filter(tg => {
    const matches = `${tg.id} ${tg.alpha} ${tg.description} ${tg.tag}`.toLowerCase().includes(query);
    return matches && (!recentOnly || tg.recent);
  });
  $("grid-count").textContent = `${rows.length} TALKGROUP${rows.length === 1 ? "" : "S"}`;
  if (!rows.length) {
    $("cards").innerHTML = '<div class="empty">No talkgroups match this view.</div>';
    return;
  }
  $("cards").innerHTML = rows.map(tg => {
    const title = tg.alpha || `TG ${tg.id}`;
    const detail = tg.description || tg.tag || "No alias description";
    const state = tg.recent ? "RECENT" : tg.count ? "SEEN" : "IDLE";
    const eventLine = tg.message ? esc(tg.message) : "No activity recorded yet";
    return `<article class="tg-card ${tg.recent ? "is-recent" : ""}">
      <div class="card-head">
        <div class="card-title"><h2 title="${esc(title)}">${esc(title)}</h2><span class="tg-id">TG ${esc(tg.id)}</span></div>
        <span class="drag-mark" aria-hidden="true">✣</span>
        <p class="description" title="${esc(detail)}">${esc(detail)}</p>
      </div>
      <div class="card-meta">
        <span class="activity-state ${tg.recent ? "recent" : "idle"}"><i></i>${state}</span>
        <span class="meta-chip">EVENTS <b>${Number(tg.count) || 0}</b></span>
        <span class="meta-chip">${tg.source ? `RADIO <b>${esc(tg.source)}</b>` : "RADIO <b>—</b>"}</span>
      </div>
      <div class="card-last"><span>LAST SEEN: ${esc(ageText(tg.last_epoch ? Date.now()/1000 - tg.last_epoch : null))}</span><i class="signal-dot ${tg.recent ? "on" : ""}" title="${state}"></i></div>
      <div class="card-event" title="${eventLine}">${eventLine}</div>
    </article>`;
  }).join("");
}

async function refresh() {
  try {
    const response = await fetch("/api/status", {cache:"no-store"});
    data = await response.json();
    $("live-state").classList.toggle("offline", !data.online);
    $("live-state").querySelector("span").textContent = data.online ? "LOG DATA LIVE" : "WAITING FOR DATA";
    render();
  } catch (_) {
    $("live-state").classList.add("offline");
    $("live-state").querySelector("span").textContent = "RECONNECTING";
  }
}

$("search").addEventListener("input", render);
$("recent-only").addEventListener("change", render);
document.querySelectorAll(".size-button").forEach(button => button.addEventListener("click", () => {
  document.querySelectorAll(".size-button").forEach(item => item.classList.toggle("selected", item === button));
  $("cards").className = `cards ${button.dataset.size}`;
}));
refresh();
setInterval(refresh, 1500);
