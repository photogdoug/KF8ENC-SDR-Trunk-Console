const $ = (id) => document.getElementById(id);
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const ageText = seconds => seconds == null ? "—" : seconds < 2 ? "just now" : seconds < 60 ? `${Math.floor(seconds)}s ago` : `${Math.floor(seconds / 60)}m ago`;
let latest = null;

function renderSites(rows) {
  const body = $("sites-body");
  $("sites-badge").textContent = `${rows.length} SITE${rows.length === 1 ? "" : "S"}`;
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty">Waiting for adjacent-site messages…</td></tr>';
    return;
  }
  body.innerHTML = rows.map(site => `<tr>
    <td class="mono">${esc(site.rfss)}</td><td class="site-code">${esc(site.site)}</td>
    <td class="mono">${esc(site.channel || "—")}</td><td class="service">${esc(site.services || "—")}</td>
    <td class="mono" title="${esc(site.last_seen)}">${esc(ageText(Date.now()/1000 - site.last_epoch))}</td>
  </tr>`).join("");
}

function renderTalkgroups(rows) {
  const body = $("talkgroups-body");
  const query = $("filter").value.trim().toLowerCase();
  const filtered = rows.filter(tg => `${tg.id} ${tg.alpha} ${tg.description} ${tg.tag}`.toLowerCase().includes(query));
  $("tg-count").textContent = rows.length;
  if (!filtered.length) {
    body.innerHTML = `<tr><td colspan="4" class="empty">${rows.length ? "No talkgroups match this filter." : "Waiting for talkgroup activity…"}</td></tr>`;
    return;
  }
  body.innerHTML = filtered.map(tg => `<tr>
    <td><span class="${tg.recent ? "pill-recent" : "pill-seen"}">${tg.recent ? "RECENT" : "SEEN"}</span></td>
    <td><div class="tg-main"><strong>${esc(tg.alpha || `TG ${tg.id}`)}</strong><small>${esc(tg.id)}${tg.source ? ` · Radio ${esc(tg.source)}` : ""}</small></div></td>
    <td>${esc(tg.description || tg.message || "No alias in list")}</td>
    <td class="mono" title="${esc(tg.last_seen)}">${esc(ageText(Date.now()/1000 - tg.last_epoch))}</td>
  </tr>`).join("");
}

function renderEvents(rows) {
  const list = $("events-list");
  $("event-count").textContent = rows.length;
  if (!rows.length) {
    list.innerHTML = '<div class="empty">Waiting for new log entries…</div>';
    return;
  }
  list.innerHTML = rows.slice(0, 100).map(event => `<div class="event-row">
    <span class="event-time">${esc(event.time)}</span>
    <span class="event-type ${esc(event.kind.toLowerCase())}">${esc(event.kind)}</span>
    <span class="event-message" title="${esc(event.message)}">${esc(event.message)}</span>
    <span class="event-tg">${event.talkgroup ? `<b>${esc(event.alpha || `TG ${event.talkgroup}`)}</b> · ${esc(event.talkgroup)}` : "—"}</span>
  </div>`).join("");
}

async function refresh() {
  try {
    const response = await fetch("/api/status", {cache:"no-store"});
    const data = await response.json();
    latest = data;
    $("system-id").textContent = data.system_id;
    $("nac").textContent = data.nac;
    $("frequency").textContent = data.control_frequency;
    $("last-data").textContent = data.last_data_time;
    $("system-name").textContent = data.system_id === "—" ? "Listening for decoded system data" : `P25 System ${data.system_id}`;
    $("log-path").textContent = data.log_dir;
    $("site-count").textContent = data.sites.length;
    $("file-count").textContent = data.file_count;
    $("alias-count").textContent = `${data.alias_count} talkgroup names loaded`;
    $("connection").classList.toggle("offline", !data.online);
    $("connection").querySelector("span").textContent = data.online ? "LIVE DATA" : "WAITING FOR DATA";
    $("feed-status").textContent = data.online ? "LOG STREAM ACTIVE" : "WAITING FOR LOG ENTRIES";
    $("notice").hidden = !data.error;
    $("notice").textContent = data.error || "";
    renderSites(data.sites);
    renderTalkgroups(data.talkgroups);
    renderEvents(data.events);
  } catch (error) {
    $("connection").classList.add("offline");
    $("connection").querySelector("span").textContent = "SERVER UNAVAILABLE";
    $("feed-status").textContent = "RECONNECTING";
  }
}

function tickClock() { $("clock").textContent = new Date().toLocaleTimeString([], {hour12:false}); }
$("filter").addEventListener("input", () => { if (latest) renderTalkgroups(latest.talkgroups); });
tickClock();
setInterval(tickClock, 1000);
refresh();
setInterval(refresh, 1500);
